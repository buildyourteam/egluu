export {
  usePeopleListStateTs,
  usePeopleListEffectTs,
  useWantedPeopleListEffectTs
} from "./usePeopleListTs";
