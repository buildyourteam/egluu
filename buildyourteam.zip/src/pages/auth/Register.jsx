import React, { useState } from "react";
import {
  Button,
  Form,
  FormGroup,
  Label,
  Input,
  Container,
  Row,
  Col
} from "reactstrap";
import { Layout } from "../../components";
import { useRegisterEffect } from "../../hook/auth";
import "./Login.css";

const Register = () => {
  const [state, setState] = useState({
    userId: "",
    userEmail: "",
    password: "",
    name: ""
  });
  const { postRegisterFetch } = useRegisterEffect();

  const handleChange = e => {
    setState({
      ...state,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = e => {
    e.preventDefault();
    postRegisterFetch(state);
    setState({ userId: "", userEmail: "", password: "", name: "" });
  };

  return (
    <Layout>
      <Container>
        <Row xs="3">
          <Col></Col>
          <Col className="loginBox">
            <h3 className="loginHeader">Create your Account</h3>
            <br />
            <Form onSubmit={handleSubmit}>
              <FormGroup>
                <Label for="id">UserId</Label>
                <Input
                  type="id"
                  name="userId"
                  id="userId"
                  placeholder="userId"
                  value={state.userId}
                  onChange={handleChange}
                />
              </FormGroup>
              <FormGroup>
                <Label for="exampleEmail">Email</Label>
                <Input
                  type="email"
                  name="userEmail"
                  id="exampleEmail"
                  placeholder="email"
                  value={state.userEmail}
                  onChange={handleChange}
                />
              </FormGroup>
              <FormGroup>
                <Label for="examplePassword">Password</Label>
                <Input
                  type="password"
                  name="password"
                  id="examplePassword"
                  placeholder="password placeholder"
                  value={state.password}
                  onChange={handleChange}
                />
              </FormGroup>
              <FormGroup>
                <Label for="id">Name</Label>
                <Input
                  type="name"
                  name="name"
                  id="name"
                  placeholder="name"
                  value={state.name}
                  onChange={handleChange}
                />
              </FormGroup>
              <div className="loginSubmit">
                <Button>Submit</Button>
              </div>
            </Form>
          </Col>
          <Col></Col>
        </Row>
      </Container>
    </Layout>
  );
};

export default Register;
